<div id="sidebar" class="user">
	<div><h3>Account Home</h3></div>
	<div>
		<ul>
			<li><a href="client.php" class="dash">Dashboard</a></li>
			<li><a href="change_user_info.php" class="changeuser">Change User Info</a></li>
			<li><a href="change_password.php" class="changepass">Change Password</a></li>
		</ul>
	</div>
</div>