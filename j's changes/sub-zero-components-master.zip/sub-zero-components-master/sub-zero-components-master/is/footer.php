
</div><!--end wrap class -->
<div class="container footer"><!-- footer container-->
	<div class="row">
		<div class="fourcol">
        	<div id="flogo">
            	<a href="home.php">SubZero Components</a>
            </div>
            <div>
            	<p><a href="background.php">Company Background</a></p> 
            	<p><a href="policy.php">Policies</a></p>
            </div>
        </div>
        
		<div class="eightcol last">

			<p>This site is not official and is an assignment for a UCF Digital Media course</p>
			<p>Designed by Group 3</p>
            
		</div>
	</div>
</div><!-- end footer container -->
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>	
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/rating.js"></script>
	<script type="text/javascript" src="js/test.js"></script>
	
</body>
</html>