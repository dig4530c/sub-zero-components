sub-zero-components
===================
There is a file named is/dash.php that has the mysql connection information. Its the only place you need to add your NID, pw and database name( I typed tablename by mistake).


Live URL is up. Check Trello or Canvas
