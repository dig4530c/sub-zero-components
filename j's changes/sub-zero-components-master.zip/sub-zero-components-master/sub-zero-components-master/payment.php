<?php 
$page_title = "Sub Zero Components - Payment";
include ('is/header.php'); 

?>

    <!-- stuff -->
    <div class="container  "><!--  container-->
      <div class="row space">
        <div class="row">
      
          <div class="ninecol "> <!--cart col-->
            <div>
              <div class="seperate">
                <p>Thanks for your purchase! We look forward to seeing you again!</p>
              </div>
            </div>
          </div>
          <div class="threecol last">
           
          </div>
        </div><!--end row-->
        
        </div>
    </div>
<?php include ('is/footer.php'); ?>