<?php
error_reporting(E_ALL &~E_NOTICE &~E_WARNING &~E_DEPRECATED);
?>

<?php 
$page_title = "Sub Zero Components - Confirmation";
include ('is/header.php'); 
?>

		<!-- stuff -->
		<div class="container  "><!--  container-->
			<div class="row space clear">
				<div class="row">
			
					<div class="ninecol "> <!--cart col-->
						<h1>Confirmation</h1>
						<br />
						<h3>Thank You! Your Order Has Been Placed
                        <br />
                        A confirmation message will be sent to your email
                        <br />
                        Order Number: #
                        </h3>

					</div>
					<div class="threecol last">
						<div >
							<!-- img box? -->
						
						</div>
					</div>
				</div><!--end row-->
				
				</div>
		</div>
<?php include ('is/footer.php'); ?>